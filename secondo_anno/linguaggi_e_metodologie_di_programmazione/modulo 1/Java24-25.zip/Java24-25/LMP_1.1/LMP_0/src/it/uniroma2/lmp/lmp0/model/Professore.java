/**
 * 
 */
package it.uniroma2.lmp.lmp0.model;

/**
 * 
 */
public interface Professore extends Persona {

	//per scontato anche i metodi son tutti public
	String getCattedra();
}
