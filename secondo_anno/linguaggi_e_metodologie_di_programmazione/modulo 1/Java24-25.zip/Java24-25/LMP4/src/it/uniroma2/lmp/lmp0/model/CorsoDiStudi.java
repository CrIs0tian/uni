package it.uniroma2.lmp.lmp0.model;

public enum CorsoDiStudi {
    INFORMATICA, PSICOLOGIA, LETTERE;
}
