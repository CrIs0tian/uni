public class AttributoMancanteException extends Exception{
    public AttributoMancanteException(String attributo){
        super("Attributo" + attributo +" mancante!");
    }
}
