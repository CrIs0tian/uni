public class InizioAttivitaFuoriRangeException extends Exception {
    public InizioAttivitaFuoriRangeException(int in_attivita_dal) {
        super("L'anno " + in_attivita_dal + " è fuori dal range ammesso per l'inizio attività");
    }
}
