public class Associazione extends Attivita{
    ScopoAssociazione scopo;
    public Associazione(int in_attivita_dal, String sede, ScopoAssociazione scopo) throws InizioAttivitaFuoriRangeException {
        super(in_attivita_dal, sede);
        this.scopo = scopo;
    }
    public static enum ScopoAssociazione {
        ricreativo, culturale, volontariato;
    }

    public ScopoAssociazione getScopo() {
        return scopo;
    }
    @Override
    public String toString() {
        return super.toString() + "\nscopo= " + this.scopo + "\n";
    }
}
