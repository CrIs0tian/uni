public class Ristorante extends AttivitaCommerciale{
    Categoria categoria;

    public Ristorante(int in_attivita_dal, String sede, String partitaIva, Categoria categoria) throws InizioAttivitaFuoriRangeException {
        super(in_attivita_dal, sede, partitaIva);
        this.categoria = categoria;
    }

    public static enum Categoria {
        pizzeria, italiano, etnico;
    }

    @Override
    public String toString() {
        return super.toString() + "\ncategoria= " + this.categoria + "\n";
    }
}
