public abstract class AttivitaCommerciale extends Attivita{
    public String partitaIva;
    public AttivitaCommerciale(int in_attivita_dal, String sede, String partitaIva) throws InizioAttivitaFuoriRangeException {
        super(in_attivita_dal, sede);
        this.partitaIva = partitaIva;
    }

    public String getPartitaIva() {
        return partitaIva;
    }

    @Override
    public String toString() {
        return super.toString() + "\npartita iva= " + this.partitaIva;
    }
}
