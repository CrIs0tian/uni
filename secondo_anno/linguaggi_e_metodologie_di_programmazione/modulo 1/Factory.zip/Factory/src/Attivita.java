public abstract class Attivita {
    public int in_attivita_dal;
    public String sede;

    public Attivita(int in_attivita_dal, String sede) throws InizioAttivitaFuoriRangeException {
        if(in_attivita_dal < 1800 || in_attivita_dal > 2022){
            throw new InizioAttivitaFuoriRangeException(in_attivita_dal);
        }
        this.in_attivita_dal = in_attivita_dal;
        this.sede = sede;
    }

    public int getIn_attivita_dal() {
        return in_attivita_dal;
    }
    public String getSede(){
        return sede;
    }

    @Override
    public String toString() {
        return "in_attivita_dal= " + in_attivita_dal + "\nsede= " + sede;
    }
}
