import java.io.File;
import java.io.IOException;

public class CardReader {
    public Attivita creaAttivita(File file) throws AttributoMancanteException, IOException, CartaInvalidaException, InizioAttivitaFuoriRangeException {
        LettoreFile lf = new LettoreFile(file);
        String fileType = lf.getFileType();

        switch(fileType){
            case("negozio"):
                return new Negozio(getAnnoAttivita(lf), getSede(lf), getPartitaIva(lf), getMerceVenduta(lf));
            case("ristorante"):
                Ristorante ristorante = new Ristorante(getAnnoAttivita(lf), getSede(lf), getPartitaIva(lf), Ristorante.Categoria.valueOf(getCategoria(lf)));
                return ristorante;
            case("associazione"):
                Associazione associazione = new Associazione(getAnnoAttivita(lf), getSede(lf), Associazione.ScopoAssociazione.valueOf(getScopo(lf)));
                return associazione;


            default:
                throw new CartaInvalidaException("Attività sconosciuta: " + fileType);

        }
    }
    public Attivita creaAttivita(String filePath) throws AttributoMancanteException, IOException, CartaInvalidaException, InizioAttivitaFuoriRangeException {
        return creaAttivita(new File(filePath));
    }
    public int getAnnoAttivita(LettoreFile lf) throws AttributoMancanteException {
        return Integer.parseInt(lf.getValue("in_attivita_dal"));
    }
    public String getSede(LettoreFile lf) throws AttributoMancanteException {
        return lf.getValue("sede");
    }
    public String getPartitaIva(LettoreFile lf) throws AttributoMancanteException {
        return lf.getValue("partita_IVA");
    }
    public String getMerceVenduta(LettoreFile lf) throws AttributoMancanteException {
        return lf.getValue("merce_venduta");
    }
    public String getCategoria(LettoreFile lf) throws AttributoMancanteException {
        return lf.getValue("categoria");
    }
    public String getScopo(LettoreFile lf) throws AttributoMancanteException {
        return lf.getValue("scopo");
    }
}
