import java.io.IOException;

public class Test {
    public static void main(String args[]) throws AttributoMancanteException, IOException, CartaInvalidaException, InizioAttivitaFuoriRangeException {
        CardReader cr = new CardReader();
        Attivita at1 = cr.creaAttivita("negozio.txt");
        System.out.println(at1);

        Attivita at2 = cr.creaAttivita("ristorante.txt");
        System.out.println(at2);

        Attivita at3 = cr.creaAttivita("associazione.txt");
        System.out.println(at3);
    }
}
