import com.sun.tools.attach.AttachOperationFailedException;

import java.io.*;
import java.util.HashMap;

public class LettoreFile {
    private HashMap<String, String> mappa;
    public static final String FILETYPE = "filetype";

    public LettoreFile(File file) throws IOException, AttributoMancanteException {
        mappa = new HashMap<String, String>();
        BufferedReader br = new BufferedReader(new FileReader(file));

        String line;
        while( (line = br.readLine() )!= null){
            //<attributo>:<valore>
           String[] elements = line.split(":");
           mappa.put(elements[0], elements[1]);
        }
        if(!mappa.containsKey(FILETYPE)){
            throw new AttributoMancanteException(FILETYPE);
        }
    }
    public String getValue(String chiave) throws AttributoMancanteException {
        if(mappa.containsKey(chiave) == true){
            return this.mappa.get(chiave);
        }
        throw new AttributoMancanteException(chiave);
    }
    public String getFileType(){
            return this.mappa.get(FILETYPE);
    }
}
