import java.rmi.server.ExportException;
public class CartaInvalidaException extends Exception {
    public CartaInvalidaException(String msg){
        super(msg);
    }
}
