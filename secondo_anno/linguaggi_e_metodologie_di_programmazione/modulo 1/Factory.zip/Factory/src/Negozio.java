public class Negozio extends AttivitaCommerciale{
    public String merceVenduta;
    public Negozio(int in_attivita_dal, String sede, String partitaIva, String merceVenduta) throws InizioAttivitaFuoriRangeException {
        super(in_attivita_dal, sede, partitaIva);
        this.merceVenduta = merceVenduta;
    }

    @Override
    public String toString() {
        return super.toString() + "\nmerce_venduta= " + this.merceVenduta + "\n";
    }
}
